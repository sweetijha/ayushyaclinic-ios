import React, { Component } from 'react';
import { Header } from 'react-native-elements';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TouchableHighlight,
  KeyboardAvoidingView,
  ScrollView,
  Animated,
  Keyboard,
  AsyncStorage,
  Dimensions,
  TouchableOpacity,
  TextInput,
} from 'react-native';

const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;

class My_Account extends Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      name: '',
      email: '',
      loggedIn : false,
      user_id : '',
      phone : ''
    };
  }
  componentDidMount() {
    AsyncStorage.getItem("loginData").then((value) => {
        if(value == null){
           this.setState({
             loggedIn : false
           });
        }
        else{
          this.setState({
             loggedIn : true,
             name : JSON.parse(value).name,
             email : JSON.parse(value).email_id,
             user_id : JSON.parse(value).user_id,
             phone : JSON.parse(value).phone
           });
        }
    }).done();
}
  navigateToHome() {
    this.props.navigation.navigate('Home');
  }
   navigateToAllToken() {
    this.props.navigation.navigate('Token');
  }
  updateProfile(){
    fetch('http://softbizz.in/Ayushya-clinic/api/public/Update_Profile', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: this.state.name,
        user_id: this.state.user_id,
        email_id: this.state.email
      }),
    })
      .then(response => response.json())
      .then(responseJson => {
        // alert(JSON.stringify(responseJson))
        if(responseJson.error){
          alert(responseJson.message);
        }else{
          let sd = {
            "user_id" : this.state.user_id,
            "name" : this.state.name,
            "phone" : this.state.phone,
            "email_id" : this.state.email
          };
           AsyncStorage.setItem('signupData', JSON.stringify(sd))
          this.props.navigation.navigate('Home');
        }
      })
      .catch(error => {
        alert(JSON.stringify(error));
      });
  }
  render() {
    const { goBack } = this.props.navigation;
    return (
      <View style={{ height: deviceHeight }}>
        <Header
          backgroundColor="#2782d2"
          leftComponent={{
            icon: 'keyboard-backspace',
            color: 'white',
            onPress: () => goBack(),
          }}
          centerComponent={{
            text: 'My Account',
            style: { color: '#ffffff', fontSize: 22 },
          }}
        />
{       this.state.loggedIn?
<View>
        <View style={styles.phoneInputView}>
          <Text style={{ marginBottom: 6 }}>Full Name</Text>
          <TextInput style={styles.phoneInput} underlineColorAndroid="transparent" placeholder="Full Name"  value={this.state.name}
              onChangeText={text => this.setState({ name: text })}/>
          <Text style={{ marginBottom: 6, marginTop: 4 }}>Email</Text>
          <TextInput style={styles.phoneInput} placeholder="Email" underlineColorAndroid="transparent"  value={this.state.email}
              onChangeText={text => this.setState({ email: text })}/>
        </View>
        <View style={styles.submitButton}>
          <TouchableOpacity onPress = { this.updateProfile.bind(this) }>
            <Text style={styles.submitText}>Submit</Text>
          </TouchableOpacity>
        </View>
        </View>
        :
        <View style={styles.comingsoon}>
          <Image
          style={styles.imgComingSoon}
            source={require('../../images/backc.jpg')}
          />
          <View style={styles.viewData}>
            <Image
              style={styles.cimg}
                source={require('../../images/ban.png')}
              />
              <Text style={styles.textc}>
                Login to Access Your Account
              </Text>
          </View>
        </View>
}

        
      </View>
    );
  }
}
const styles = StyleSheet.create({
  phoneInput: {
    borderColor: '#808080',
    borderWidth: 1,
    height: 40,
    color: '#000000',
    width: '100%',
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
  },
  phoneInputView: {
    width: deviceWidth - 30,
    marginLeft: 15,
    marginTop: 20,
  },
  submitButton: {
    width: deviceWidth - 20,
    backgroundColor: '#2782d2',
    marginLeft: 10,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 5,
    opacity: 0.8,
    marginTop: 20,
  },
  submitText: {
    textAlign: 'center',
    fontSize: 18,
    color: 'white',
  },
  comingsoon:{
    height : deviceHeight,
    width:deviceWidth,
    
  },
  imgComingSoon:{
    width: deviceWidth,
    height: deviceHeight,
    position: 'absolute',
    zIndex: 100,
  },
  viewData: {
    zIndex: 10000,
    width: deviceWidth,
    height: deviceHeight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cimg:{
    width:deviceWidth/2,
    height:deviceWidth/2,
    position:'relative',
    top:-50
  },
  textc:{
    fontSize:30,
    color:'white',
    textAlign:'center',
    position:'relative',
    top:-50
  }
});
export default My_Account;
