import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TouchableHighlight,
  KeyboardAvoidingView,
  ScrollView,
  Animated,
  Keyboard,
  AsyncStorage,
  Dimensions,
  TouchableOpacity,
  TextInput,
} from 'react-native';

const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;

class Signup extends Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      name: '',
      phone: '',
      email_id: '',
      password: '',
      Confirm_password: '',
    };
  }
  componentDidMount() {
    AsyncStorage.getItem('signupData')
      .then(value => {
        if (value) {
          this.props.navigation.navigate('Home');
        }
      })
      .done();
  }
  navigateToHome() {
    fetch('http://softbizz.in/Ayushya-clinic/api/public/User_Registration', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: this.state.name,
        phone: this.state.phone,
        email_id: this.state.email_id,
        password: this.state.password,
      }),
    })
      .then(response => response.json())
      .then(responseJson => {
        if (responseJson.error) {
          alert(responseJson.message);
        } else {
          AsyncStorage.setItem('signupData', JSON.stringify(responseJson.data));
          this.props.navigation.navigate('Home');
        }
      })
      .catch(error => {
        alert(JSON.stringify(error));
      });
  }
  render() {
    return (
        <View style={{ flex: 1 }}> Toolbar
        <ScrollView>
          <Image
            style={styles.stretch}
            source={require('../../images/hospital.png')}
          />
          <View style={styles.backgroundOpacity} />
          <View style={styles.viewData}>
            <View style={styles.phoneInputView}>
              <TextInput
                style={styles.phoneInput}
                placeholder="Name"
                placeholderTextColor="#ffffff"
                value={this.state.name}
                underlineColorAndroid="transparent"
                onChangeText={text => this.setState({ name: text })}
              />
            </View>
            <View style={styles.phoneInputView}>
              <TextInput
                style={styles.phoneInput}
                placeholder="Phone"
                placeholderTextColor="#ffffff"
                value={this.state.phone}
                underlineColorAndroid="transparent"
                onChangeText={text => this.setState({ phone: text })}
              />
            </View>
            <View style={styles.phoneInputView}>
              <TextInput
                style={styles.phoneInput}
                placeholder="Email"
                placeholderTextColor="#ffffff"
                value={this.state.email_id}
                underlineColorAndroid="transparent"
                onChangeText={text => this.setState({ email_id: text })}
              />
            </View>
            <View style={styles.phoneInputView}>
              <TextInput
                style={styles.phoneInput}
                placeholder="Password"
                placeholderTextColor="#ffffff"
                value={this.state.password}
                underlineColorAndroid="transparent"
                secureTextEntry={true}
                onChangeText={text => this.setState({ password: text })}
              />
            </View>
            <View style={styles.phoneInputView}>
              <TextInput
                style={styles.phoneInput}
                placeholder="Confirm Password"
                placeholderTextColor="#ffffff"
                underlineColorAndroid="transparent"
                value={this.state.confirm_password}
                secureTextEntry={true}
                onChangeText={text => this.setState({ confirm_password: text })}
              />
            </View>
            <View style={styles.submitButton}>
              <TouchableOpacity onPress={this.navigateToHome.bind(this)}>
                <Text style={styles.loginText}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
           </ScrollView>
        </View>
     
    );
  }
}
const styles = StyleSheet.create({
  stretch: {
    width: deviceWidth,
    height: deviceHeight,
    position: 'absolute',
    zIndex: 100,
  },
  backgroundOpacity: {
    backgroundColor: 'rgba(0,0,0,0.7)',
    zIndex: 1000,
    width: deviceWidth,
    height: deviceHeight,
    position: 'absolute',
  },
  viewData: {
    zIndex: 10000,
    width: deviceWidth,
    height: deviceHeight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  submitButton: {
    width: deviceWidth - 20,
    backgroundColor: '#2782d2',
    marginLeft: 0,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 5,
    opacity: 0.8,
    marginTop: 10,
  },
  loginText: {
    textAlign: 'center',
    fontSize: 18,
    color: 'white',
  },
  phoneInput: {
    borderColor: '#7cb9b9',
    borderWidth: 1,
    height: 40,
    color: 'white',
    width: '100%',
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
    marginTop: 10,
  },

  phoneInputView: {
    width: deviceWidth - 20,
    marginLeft: 0,
  },
});
export default Signup;
