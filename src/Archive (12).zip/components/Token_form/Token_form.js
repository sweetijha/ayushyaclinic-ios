import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TouchableHighlight,
  KeyboardAvoidingView,
  ScrollView,
  Animated,
  Keyboard,
  AsyncStorage,
  Dimensions,
  TouchableOpacity,
  TextInput,
  Picker,
  Platform
} from 'react-native';
import { Constants } from 'expo';
import { Header } from 'react-native-elements';
import DateTimePicker from 'react-native-modal-datetime-picker';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { createStackNavigator } from 'react-navigation';

const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;

class Token_form extends Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      name: '',
      phone: '',
      gender: '',
      dob: '',
      address: '',
      conv_time: '',
    };
  }
  navigateToToken_details() {
    this.props.navigation.navigate('Token_details');
  }
  addToken() {
    fetch('http://softbizz.in/Ayushya-clinic/api/public/Token_Generate', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        phone_number: this.state.phone,
        patient_name: this.state.name,
        gender: this.state.gender,
        dob: this.state.dob,
        address: this.state.address,
        convinient_time: this.state.conv_time,
        isDatePickerVisible: false,
        isTimePickerVisible: false,
      }),
    })
      .then(response => response.json())
      .then(responseJson => {
        // alert(JSON.stringify(responseJson));
        if (responseJson.error) {
          alert(responseJson.message);
        } else {
          alert(responseJson.message);
          this.props.navigation.navigate('Current_Token');
        }
      })
      .catch(error => {
        alert(JSON.stringify(error));
      });
  }
  _showDatePicker = () => this.setState({ isDatePickerVisible: true });

  _hideDatePicker = () => this.setState({ isDatePickerVisible: false });

  _handleDatePicked = date => {
    //alert('A date has been picked: ', date.toString());
    this.setState({
      dob:
        date.getFullYear() +
        '-' +
        (parseInt(date.getMonth() + 1) < 10
          ? '0' + (date.getMonth() + 1)
          : date.getMonth() + 1) +
        '-' +
        (parseInt(date.getDate()) < 10 ? '0' + date.getDate() : date.getDate()),
    });
    this._hideDatePicker();
  };

  _showTimePicker = () => this.setState({ isTimePickerVisible: true });

  _hideTimePicker = () => this.setState({ isTimePickerVisible: false });

  _handleTimePicked = time => {
    this.setState({
      conv_time:
        (parseInt(time.getHours()) < 10
          ? '0' + time.getHours()
          : time.getHours()) +
        ':' +
        (parseInt(time.getMinutes()) < 10
          ? '0' + time.getMinutes()
          : time.getMinutes()),
    });
    // alert(time.getHours()+':'+time.getMinutes());
    this._hideTimePicker();
  };

  render() {
    const { dob } = this.state;
    const { goBack } = this.props.navigation;
    return (
      <View style={{ height: deviceHeight, flex: 1 }}>
        <ScrollView>
          <View style={styles.container}>
            <Header
              backgroundColor="#2782d2"
              leftComponent={{
                icon: 'keyboard-backspace',
                color: 'white',
                onPress: () => goBack(),
              }}
              centerComponent={{
                text: 'Token Form',
                style: { color: '#ffffff', fontSize: 22 },
              }}
            />
          </View>
          <KeyboardAwareScrollView
    enableOnAndroid
    enableAutomaticScroll
    keyboardOpeningTime={0}
    extraHeight={Platform.select({ android: 200 })}
  >
          <View style={styles.phoneInputView}>
            <Text style={{ marginBottom: 6 }}>Full Name</Text>
            <TextInput
              style={styles.phoneInput}
              placeholder="Full Name"
              value={this.state.name}
              underlineColorAndroid="transparent"
              onChangeText={text => this.setState({ name: text })}
            />
            <Text style={{ marginBottom: 6, marginTop: 4 }}>Gender</Text>
            <View style={styles.selectInput}>
            <Picker
              style={styles.pickerInput}
              selectedValue={this.state.gender}
              onValueChange={(itemValue, itemIndex) =>
                this.setState({ gender: itemValue })
              }>
              <Picker.Item label="Male" value="Male" />
              <Picker.Item label="Female" value="Female" />
            </Picker>
            </View>
            <Text style={{ marginBottom: 6, marginTop: 4 }}>Phone Number</Text>
            <TextInput
              keyboardType="numeric"
              style={styles.phoneInput}
              placeholder="Phone Number"
              value={this.state.phone}
              underlineColorAndroid="transparent"
              onChangeText={text => this.setState({ phone: text })}
            />
            <Text style={{ marginBottom: 6 }}>Date of Birth</Text>
            <TouchableOpacity onPress={this._showDatePicker}>
              <TextInput
                style={styles.phoneInput}
                placeholder="Enter Date of Birth"
                editable={false}
                value={this.state.dob}
                underlineColorAndroid="transparent"
                onChangeText={text => this.setState({ address: text })}
              />
            </TouchableOpacity>
            <DateTimePicker
              isVisible={this.state.isDatePickerVisible}
              onConfirm={this._handleDatePicked}
              onCancel={this._hideDatePicker}
              mode="date"
            />
            <Text style={{ marginBottom: 6, marginTop: 4 }}>Address</Text>
            <TextInput
              style={styles.phoneInput}
              placeholder="Address"
              value={this.state.address}
              underlineColorAndroid="transparent"
              onChangeText={text => this.setState({ address: text })}
            />
            <Text style={{ marginBottom: 6, marginTop: 4 }}>
              convinient Time
            </Text>
            <TouchableOpacity onPress={this._showTimePicker}>
              <TextInput
                style={styles.phoneInput}
                placeholder="Enter Convenient Time"
                editable={false}
                underlineColorAndroid="transparent"
                value={this.state.conv_time}
                onChangeText={text => this.setState({ address: text })}
              />
            </TouchableOpacity>
            <DateTimePicker
              isVisible={this.state.isTimePickerVisible}
              onConfirm={this._handleTimePicked}
              onCancel={this._hideTimePicker}
              mode="time"
            />
          </View>
          <View style={styles.submitButton}>
            <TouchableOpacity onPress={this.addToken.bind(this)}>
              <Text style={styles.submitText}>Submit</Text>
            </TouchableOpacity>
          </View>
          </KeyboardAwareScrollView>
        </ScrollView>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 1,
  },
  phoneInput: {
    borderColor: '#808080',
    borderWidth: 1,
    height: 40,
    color: '#000000',
    width: '100%',
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
  },
  phoneInputView: {
    width: deviceWidth - 30,
    marginLeft: 15,
    marginTop: 20,
  },
  submitButton: {
    width: deviceWidth - 20,
    backgroundColor: '#2782d2',
    marginLeft: 10,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 5,
    opacity: 0.8,
    marginTop: 20,
  },
  submitText: {
    textAlign: 'center',
    fontSize: 18,
    color: 'white',
  },
  selectInput: {
    borderColor: '#808080',
    borderWidth: 1,
    height: 40,
    width: '100%',
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
  },
  pickerInput:{
    height:40

  }
});
export default Token_form;
