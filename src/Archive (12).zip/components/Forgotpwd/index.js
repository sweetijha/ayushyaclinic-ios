export { default } from "./Forgotpwd";
