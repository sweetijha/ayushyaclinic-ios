export { default } from "./Setting";
