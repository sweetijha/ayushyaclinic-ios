import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TouchableHighlight,
  KeyboardAvoidingView,
  ScrollView,
  Animated,
  Keyboard,
  AsyncStorage,
  Dimensions,
  TouchableOpacity,
  TextInput,
  Platform
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;

class Login extends Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      phone: '',
      password: '',
      skipPage:''
    };
  }
  componentDidMount() {
    AsyncStorage.getItem("loginData").then((value) => {
        if(value){
           this.props.navigation.navigate('Home');
        }
    }).done();
    this.getToken();
}
 getToken(){
      fetch('http://softbizz.in/Ayushya-clinic/api/public/GetAllToken', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      }
    })
      .then(response => response.json())
      .then(responseJson => {
        if(responseJson.length>0)
            this.setState({skipPage : 'Current_Token'});
        else
            this.setState({skipPage : 'Home'});
         
      })
      .catch(error => {
        alert(JSON.stringify(error));
      });
    }
  navigateToHome() {
    fetch('http://softbizz.in/Ayushya-clinic/api/public/User_login', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        phone: this.state.phone,
        password: this.state.password
      }),
    })
      .then(response => response.json())
      .then(responseJson => {
        if(responseJson.error){
          alert(responseJson.message);
        }else{
          AsyncStorage.setItem('loginData', JSON.stringify(responseJson.data))
          this.props.navigation.navigate(this.state.skipPage);
        }
      })
      .catch(error => {
        alert(JSON.stringify(error));
      });
  }
  navigateToForgotpwd(){
    this.props.navigation.navigate('Forgotpwd');
  }
  render() {
    return (
      <KeyboardAwareScrollView
    enableOnAndroid
    enableAutomaticScroll
    keyboardOpeningTime={0}
    extraHeight={Platform.select({ android: 200 })}
  >
      <View>
        <Image
          style={styles.stretch}
          source={require('../../images/hospital.png')}
        />
        <View style={styles.backgroundOpacity} />
        <View style={styles.viewData}>
          <View style={styles.phoneInputView}>
            <TextInput
              style={styles.phoneInput}
              placeholder="Phone"
              placeholderTextColor="#ffffff"
              value={this.state.phone}
              onChangeText={text => this.setState({ phone: text })}
            />
          </View>
          <View style={styles.pwdInputView}>
            <TextInput
              style={styles.pwdInput}
              placeholder="Password"
              placeholderTextColor="#ffffff"
              value={this.state.password}
              secureTextEntry={true}
              onChangeText={text => this.setState({ password: text })}
            />
          </View>
          <View style={styles.loginButton}>
            <TouchableOpacity onPress={this.navigateToHome.bind(this)}>
              <Text style={styles.loginText}>Login</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.forgotButton}>
            <TouchableOpacity onPress={this.navigateToForgotpwd.bind(this)}>
              <Text style={styles.loginText}>Forgot Password?</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      </KeyboardAwareScrollView>
    );
  }
}
const styles = StyleSheet.create({
  stretch: {
    width: deviceWidth,
    height: deviceHeight,
    position: 'absolute',
    zIndex: 100,
  },
  backgroundOpacity: {
    backgroundColor: 'rgba(0,0,0,0.7)',
    zIndex: 1000,
    width: deviceWidth,
    height: deviceHeight,
    position: 'absolute',
  },
  viewData: {
    zIndex: 10000,
    width: deviceWidth,
    height: deviceHeight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loginButton: {
    width: deviceWidth - 20,
    backgroundColor: '#2782d2',
    marginLeft: 0,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 5,
    opacity: 0.8,
  },
  loginText: {
    textAlign: 'center',
    fontSize: 18,
    color: 'white',
  },
  phoneInput: {
    borderColor: '#7cb9b9',
    borderWidth: 1,
    height: 40,
    color: 'white',
    width: '100%',
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
  },
  pwdInput: {
    borderColor: '#7cb9b9',
    borderWidth: 1,
    height: 40,
    color: 'white',
    width: '100%',
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
    marginTop: 10,
    marginBottom: 15,
  },
  phoneInputView: {
    width: deviceWidth - 20,
    marginLeft: 0,
  },
  pwdInputView: {
    width: deviceWidth - 20,
    marginLeft: 0,
  },
  forgotButton: {
    width: deviceWidth - 30,
    marginLeft: 0,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 10,
    opacity: 0.8,
  },
});
export default Login;
